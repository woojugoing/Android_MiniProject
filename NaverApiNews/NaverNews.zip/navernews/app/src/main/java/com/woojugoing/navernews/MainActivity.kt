package com.woojugoing.navernews

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.woojugoing.navernews.databinding.ActivityMainBinding
import com.woojugoing.navernews.databinding.RowBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

// X-Naver-Client-Id : EaaZXbc7EIQKr6IByAYs
// X-Naver-Client-Secret : bLbzmeTBSN
// Package Name : com.woojugoing.navernews

class MainActivity : AppCompatActivity() {

    lateinit var activityMainBinding: ActivityMainBinding
    private val adapter = Adapter()
    private val newsList: MutableList<Items> = mutableListOf()
    private lateinit var webView: WebView

    val clientID = "EaaZXbc7EIQKr6IByAYs"
    val clientSecret = "bLbzmeTBSN"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityMainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(activityMainBinding.root)

        activityMainBinding.run {
            searchView.editText.setOnEditorActionListener { v, actionId, event ->
                val retrofit = Retrofit.Builder()
                    .baseUrl("https://openapi.naver.com/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()

                val api = retrofit.create(NaverAPI::class.java)
                val callGetSearchNews = api.getSearchNews(clientID, clientSecret, "${searchView.editText.text}", 20, 1, "date")
                callGetSearchNews.enqueue(object : Callback<ResultGetSearchNews> {
                    override fun onResponse(
                        call: Call<ResultGetSearchNews>,
                        response: Response<ResultGetSearchNews>
                    ) {
                        val result = response.body()
                        result?.items?.let {
                            adapter.setNewsItems(it)
                            adapter.notifyDataSetChanged()
                        }
                        Log.d("성공", "${response.raw()}")
                    }

                    override fun onFailure(call: Call<ResultGetSearchNews>, t: Throwable) {}
                })
                false
            }

            recyclerView.run {
                adapter = this@MainActivity.adapter
                layoutManager = LinearLayoutManager(this@MainActivity)
            }
        }

    }

    inner class Adapter(): RecyclerView.Adapter<Adapter.HolderClass>() {

        fun setNewsItems(items: List<Items>) {
            newsList.clear()
            newsList.addAll(items)
            notifyDataSetChanged()
        }

        inner class HolderClass(rowBinding: RowBinding): RecyclerView.ViewHolder(rowBinding.root){
            val textViewRow: TextView

            init {
                textViewRow = rowBinding.textViewRow
                rowBinding.root.setOnClickListener {
                    var intent = Intent(Intent.ACTION_VIEW, Uri.parse(newsList[adapterPosition].originallink))
                    startActivity(intent)
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderClass {
            val rowBinding = RowBinding.inflate(layoutInflater)
            val holderClass = HolderClass(rowBinding)

            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rowBinding.root.layoutParams = params

            return holderClass
        }

        override fun getItemCount(): Int {
            return newsList.size
        }

        override fun onBindViewHolder(holder: HolderClass, position: Int) {
            var title = newsList[position].title
            title = Html.fromHtml(title).toString()
            holder.textViewRow.text = title
        }

    }
}

data class ResultGetSearchNews(
    var lastBuildDate: String = "",
    var total: Int = 0,
    var start: Int = 0,
    var display: Int = 0,
    var items: List<Items>
)

data class Items(
    var title: String = "",
    var originallink: String = "",
    var link: String = "",
    var description: String = "",
    var pubDate: String = ""
)

interface NaverAPI {
    @GET("v1/search/news.json")
    fun getSearchNews(
        @Header("X-Naver-Client-Id") clientId: String,
        @Header("X-Naver-Client-Secret") clientSecret: String,
        @Query("query") query: String,
        @Query("display") display: Int? = null,
        @Query("start") start: Int? = null,
        @Query("sort") sort: String = "sim"
    ): Call<ResultGetSearchNews>
}

